import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class Circle extends Shape 
{
	private int radius; //rad. of circle
	
	//circle constructor
	public Circle(int x, int y, Color color, int radius) {
		super(x, y, color);
		this.radius = radius;
		setX(x);
		setY(y);
		setColor(color);
	}
	
	//getters
	public int getRadius() {
		return this.radius;
	}
	
    //returns the area of circle
    public double getArea()
    {return Math.PI * radius * radius;}
    
	//returns the perimeter of circle
	public double getPerimeter()
	{return 2 * Math.PI * radius;}
	
	
    public String toString() 
	{	String result = "Circle[ Radius=" +getRadius()+  
	", Perimeter=" + getPerimeter()+ ", Area = " +getArea()+ "]";
    	return result;
    }

@Override
	public void draw(Graphics g)
	{
		g.setColor(getColor());
		g.fillOval( getX()-getRadius(), getY()-getRadius() ,getRadius() * 2, getRadius() * 2);
		
	}
	
}