import java.awt.Color;
import java.awt.Graphics;
import java.awt.Polygon;

import javax.swing.JPanel;

public  class DrawPolygon extends Shape
{
	private int N;
	private int radius; //rad. of circle
	
	//polygon Constructor
	public DrawPolygon(int x, int y, Color color, int N,int radius) {
		super(x, y, color);
		this.N = N;
		this.radius = radius;
	}
	//getters
	public int getRadius() {
		return radius;
	}

	//setters
	public void setRadius(int radius) {
		this.radius = radius;
	}	
	
	
	//returns the area of Polygon
	public double getArea()
	{
		double area = (1/4) * N * ((getSide() * getSide())/(Math.tan(Math.PI/N)));
		return area;
    }
	
	
	//returns the Perimeter of Polygon
	public int getPerimeter()
	{return N * getSide();}
		
		
	//returns the interior angle (in degrees) of the Polygon
	public double getAngle() 
	{	double angleInterior = (N-2) * 180/N;
		return angleInterior;
	}
	
	
	
	public int getSide()
	{	
		int sideLength = (int) (2 * getRadius() * Math.PI/N);
		return sideLength;
	}
	
	
    public String toString() {
    	String result = "( side length = " + getSide() +
    			", interior angle = " + getAngle()  + ", perimeter = " + 
    			getPerimeter() + ", area = " + getArea() + ")";
        return result;
    }
	
    @Override
	public void draw(Graphics g)
	{	
		Polygon p = new Polygon();
		
		
	    for (int i = 0; i < N; i++)
	    {
	      //p.addPoint(x, y);
	      p.addPoint((int) (getX() + getRadius() * Math.cos(i * 2 * Math.PI / N)),
	          (int) (getY()- getRadius() * Math.sin(i * 2 * Math.PI / N)));
	    }
	   
		 g.setColor(getColor());
		 g.fillPolygon(p);
	}

}
