import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class DrawShapeTest extends Canvas {
	public DrawShapeTest() {
		setBackground(Color.WHITE);
	}
	public void paint(Graphics g) {
		int centerX = getWidth()/2;
		int centerY = getHeight()/2;
		
		Shape c1 = new	Circle(centerX, centerY, Color.PINK, 400);
		Shape c2 = new Circle(centerX, centerY, Color.decode("#99FF33"), 320);
		Shape c3 = new Circle(centerX, centerY, Color.CYAN, 240);
		Shape c4 = new Circle(centerX, centerY, Color.WHITE, 190);
		
		Shape p1 = new DrawPolygon(centerX, centerY, Color.decode("#FFFFCC"), 5,400);
		Shape p2 = new DrawPolygon(centerX, centerY, Color.decode("#CCCCFF"), 5,300);
		Shape p3 = new DrawPolygon(centerX, centerY, Color.decode("#8B0000"), 5,235);
		
		c1.draw(g);
		p1.draw(g);
		c2.draw(g);
		p2.draw(g);
		c3.draw(g);
		p3.draw(g);
		c4.draw(g);
		
		g.setColor(Color.BLACK);
		g.drawString("Excercise 1 by Eftekher Husain", centerX-100, centerY);
		
		
		int width = getWidth();
		int height = getHeight();
		g.setColor(Color.BLACK);
		g.drawRect(220, 50, 1000, 800);
		g.drawLine(220, 50, 1220, 850);
		g.drawLine(220, 850, 1220, 50);
		
	}

	public static void main(String[] args) {
		
				
		JFrame frame = new JFrame("Excercise 1 By Eftekher Husain");
		DrawShapeTest drawShapes = new DrawShapeTest();
		
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.add(drawShapes);
		
		frame.setSize(1000, 1000);
		frame.setVisible(true);
	}
}
