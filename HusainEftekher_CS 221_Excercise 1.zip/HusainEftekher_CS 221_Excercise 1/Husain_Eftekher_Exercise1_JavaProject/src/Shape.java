import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public abstract class Shape extends Canvas {
	private int x;
	private int y;
	private int dx;
	private int dy;
	private Color color;
	
	//constructor
	public Shape(int x, int y, Color color) {
		super();
		this.x = x;
		this.y = y;
		this.color = color;
	}
	
	
	//getters
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	public int getDx() {
		return dx;
	}
	public int getDy() {
		return dy;
	}
	public Color getColor() {
		return color;
	}
	
	
	//setters
	public void setX(int x) {
		this.x = x;
	}
	public void setY(int y) {
		this.y = y;
	}
	public void setDx(int dx) {
		this.dx = dx;
	}
	public void setDy(int dy) {
		this.dy = dy;
	}
	public void setColor(Color color) {
		this.color = color;
	}
	
	//moves point (x, y) by (∆x, ∆y);
	public void shiftXY(int dx, int dy)
	{
		x += dx;
		y =+ dy;
	}
	
	//returns the object's description as a String
	public String toString()
	{	String shape = "Shape[ x =" + getX() + ",y = " + getY() + "color = " + getColor();
		return shape;
	}
	

	public abstract void draw(Graphics g);

}
